
# Topeka N‑Trak PWA (Azure Static Web Apps)

This is a zero-DB, low-cost site + API you can deploy on **Azure Static Web Apps**.

## Features
- Installable **PWA** (Add to Home Screen on iOS/Android/desktop)
- Pages: Home, Events, Roster, Join/Contact
- Data from simple JSON files (no SQL)
- API placeholders for `/api/join` and `/api/contact` (Azure Functions)

## Deploy (GitHub workflow – easiest)
1. Create a GitHub repo and push this folder.
2. In Azure Portal: **Create** → **Static Web App**
   - Deployment source: **GitHub**
   - App location: `site`
   - API location: `api`
   - Build presets: **Custom**
3. After deploy, the site will build and host automatically.
4. Add a **Custom domain** (e.g., `beta.topekantrak.com`) via CNAME in DNS.

## Local edit
- Edit JSON at `site/data/events.json` and `site/data/roster.json` to update content.
- For forms, wire your email or storage inside `api/join/index.js` and `api/contact/index.js`.

## Email on form submit (optional)
- Add SendGrid (or SMTP) code to the Function to send an email to the club address.
- Or write to Azure Table Storage / Cosmos DB (serverless).

## DNS cut-over
- Keep Wix live. Launch on a subdomain first (beta).
- When ready, point `www.topekantrak.com` to the Static Web App.
- Use Azure Front Door or a DNS provider with CNAME flattening for the apex domain.

